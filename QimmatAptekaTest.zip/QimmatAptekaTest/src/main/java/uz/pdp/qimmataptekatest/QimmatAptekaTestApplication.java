package uz.pdp.qimmataptekatest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;
import org.telegram.telegrambots.meta.api.objects.Update;
import uz.pdp.qimmataptekatest.payload.DefaultUser;

@SpringBootApplication
@EnableFeignClients
public class QimmatAptekaTestApplication {

    public static void main(String[] args) {
        SpringApplication.run(QimmatAptekaTestApplication.class, args);
    }

    @Bean
    public RestTemplate restTemplate(){
        return new RestTemplate();
    }

    @Bean
    public DefaultUser defaultUser(){
        return new DefaultUser();
    }
}
