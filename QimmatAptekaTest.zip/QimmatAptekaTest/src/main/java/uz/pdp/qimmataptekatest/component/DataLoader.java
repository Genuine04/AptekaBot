package uz.pdp.qimmataptekatest.component;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import uz.pdp.qimmataptekatest.entity.District;
import uz.pdp.qimmataptekatest.entity.Region;
import uz.pdp.qimmataptekatest.entity.enums.DistrictName;
import uz.pdp.qimmataptekatest.entity.enums.RegionName;
import uz.pdp.qimmataptekatest.repository.DistrictRepo;
import uz.pdp.qimmataptekatest.repository.RegionRepo;

import java.util.ArrayList;
import java.util.List;

@Component
@RequiredArgsConstructor
public class DataLoader implements CommandLineRunner {

    private final RegionRepo regionRepo;

    private final DistrictRepo districtRepo;

    @Value("${spring.sql.init.mode}")
    private String mode;

    @Override
    public void run(String... args) throws Exception {
        if (mode.equals("always")) {
            RegionName[] regionNames = RegionName.values();
            ArrayList<Region> regions = new ArrayList<>();
            for (RegionName regionName : regionNames) {
                regions.add(new Region(regionName.getOriginalName()));
            }
            regionRepo.saveAll(regions);


            DistrictName[] districtNames = DistrictName.values();
            ArrayList<District> districts = new ArrayList<>();
            for (DistrictName districtName : districtNames) {
                List<Region> allRegions = regionRepo.findAll();
                for (int i = 0; i < allRegions.size(); i++) {
                    if (districtName.getRegionName().equals(allRegions.get(i).getRegionName())){
                        districts.add(new District(districtName.getOriginalName(), allRegions.get(i)));
                    }
                }
            }
            districtRepo.saveAll(districts);
        }
    }
}
