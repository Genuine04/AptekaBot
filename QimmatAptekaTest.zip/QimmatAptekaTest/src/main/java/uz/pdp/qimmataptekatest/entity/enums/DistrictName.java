package uz.pdp.qimmataptekatest.entity.enums;

public enum DistrictName {


    //ANDIJON VILOYATIGA TEGISHLI TUMANLAR

    ANDIJON_TUMANI("Andijon tumani", "Andijon viloyati"),
    ASAKA_TUMANI("Asaka tumani", "Andijon viloyati"),
    IZBOSKAN_TUMANI("Izboskan tumani", "Andijon viloyati"),
    JALAQUDUQ_TUMANI("Jalaquduq tumani", "Andijon viloyati"),
    OLTINKOL_TUMANI("Oltinko'l tumani", "Andijon viloyati"),
    SHAXRIHON_TUMANI("Shaxrihon tumani", "Andijon viloyati"),
    XOJAOBOD_TUMANI("Xo'jaobod tumani", "Andijon viloyati"),
    BALICHI_TUMANI("Baliqchi tumani", "Andijon viloyati"),
    ANDIJON_SHAHRI("Andijon shahri", "Andijon viloyati"),
//    BOSTON_TUMANI("Bo'ston tumani", "Andijon viloyati"),
//    BULOQBOSHI_TUMANI("Buloqboshi tumani", "Andijon viloyati"),
//    MARHAMAT_TUMANI("Marhamat tumani", "Andijon viloyati"),
//    PAXTAOBOD_TUMANI("Paxtaobod tumani", "Andijon viloyati"),
//    ULUGNOR_TUMANI("Ulug'nor tumani", "Andijon viloyati"),
//    QORGONTEPA_TUMANI("Qo'rg'ontepa tumani", "Andijon viloyati"),
//    XONOBOD_SHAHRI("Xonobod shahri", "Andijon viloyati"),


    //FARG'ONA VILOYATIGA TEGISHLI TUMANLAR

    RISHTON_SHAHRI("Rishton shahri","Farg'ona viloyati"),
    FARGONA_SHAHRI("Farg'ona shahri","Farg'ona viloyati"),
    UCHKOPRIK_TUMANI("Uchko'prik tumani","Farg'ona viloyati"),
    YOZYOVON_TUMANI("Yozyovon tumani","Farg'ona viloyati"),
    QOQON_SHAHRI("Qo'qon shahri","Farg'ona viloyati"),
    BOGDOD_TUMANI("Bog'dod tumani","Farg'ona viloyati"),
    DANGARA_TUMANI("Dang'ara tumani","Farg'ona viloyati"),
    FARGONA_TUMANI("Farg'ona tumani","Farg'ona viloyati"),
    FURQAT_TUMANI("Furqat tumani","Farg'ona viloyati"),
    QUVA_TUMANI("Quva tumani","Farg'ona viloyati"),
    OZBEKISTON_TUMANI("O'zbekiston tumani","Farg'ona viloyati"),
//    YAYPAN_SHAHRI("Yaypan shahri","Farg'ona viloyati"),
//    QUVASOY_SHAHRI("Quvasoy shahri","Farg'ona viloyati"),
//    HAMZA_SHAHRI("Hamza shahri","Farg'ona viloyati"),
//    BESHARIQ_TUMANI("Beshariq tumani","Farg'ona viloyati"),
//    BUVAYDA_TUMANI("Buvayda tumani","Farg'ona viloyati"),
//    OLTIARIQ_TUMANI("Oltiariq tumani","Farg'ona viloyati"),
//    QOSHTEPA_TUMANI("Qo'shtepa tumani","Farg'ona viloyati"),
//    RISHTON_TUMANI("Rishton tumani","Farg'ona viloyati"),
//    SOX_TUMANI("So'x tumani","Farg'ona viloyati"),
//    TOSHLOQ_TUMANI("Toshloq tumani","Farg'ona viloyati"),
//    MARGILON_SHAHRI("Marg'ilon shahri","Farg'ona viloyati"),



    //NAMANGAN VILOYATIGA TEGISHLI TUMANLAR
    NAMANGAN_SHAHRI("Namangan shahri","Namangan viloyati"),
    KOSONSOY_TUMANI("Kosonsoy tumani","Namangan viloyati"),
    UCHQORGON_TUMANI("Uchqo'rg'on tumani","Namangan viloyati"),
    CHORTOQ_TUMANI("Chortoq tumani","Namangan viloyati"),
    YANGIQORGON_TUMANI("Yangiqo'rg'on tumani","Namangan viloyati"),
//    MINGBULOQ_TUMANI("Mingbuloq tumani","Namangan viloyati"),
//    NAMANGAN_TUMANI("Namangan tumani","Namangan viloyati"),
//    NORIN_TUMANI("Norin tumani","Namangan viloyati"),
//    POP_TUMANI("Pop tumani","Namangan viloyati"),
//    TORAQORGON_TUMANI("To'raqo'rg'on tumani","Namangan viloyati"),
//    UYCHI_TUMANI("Uychi tumani","Namangan viloyati"),
//    CHUST_TUMANI("Chust tumani","Namangan viloyati"),



    //TOSHKENT VILOYATIGA TEGISHLI TUMANLAR
    BEKOBOD_TUMANI("Bekobod tumani","Toshkent viloyati"),
    BOSTONLIQ_TUMANI("Bo'stonliq tumani","Toshkent viloyati"),
    BOKA_TUMANI("Bo'ka tumani","Toshkent viloyati"),
    CHINOZ_TUMANI("Chinoz tumani","Toshkent viloyati"),
    QIBRAY_TUMANI("Qibray tumani","Toshkent viloyati"),
    OHANGARON_TUMANI("Ohangaron tumani","Toshkent viloyati"),
    OQQORGON_TUMANI("Oqqo'rg'on tumani","Toshkent viloyati"),
    PARKENT_TUMANI("Parkent tumani","Toshkent viloyati"),
    PISKENT_TUMANI("Piskent tumani","Toshkent viloyati"),
    QUYI_CHIRCHIQ_TUMANI("Quyi chirchiq tumani","Toshkent viloyati"),
    ORTA_CHIRCHIQ_TUMANI("O'rta chirchiq tumani","Toshkent viloyati"),
    YANGIYOL_TUMANI("Yangiyo'l tumani","Toshkent viloyati"),
    YUQORI_CHIRCHIQ_TUMANI("Yuqori chirchiq tumani","Toshkent viloyati"),
    ZANGIOTA_TUMANI("Zangiota tumani","Toshkent viloyati"),


    //TOSHKENT SHAHRIGA TEGISHLI TUMANLAR
    BEKTEMIR_TUMANI("Bektemir tumani","Toshkent shahri"),
    CHILONZOR_TUMANI("Chilonzor tumani","Toshkent shahri"),
    HAMZA_TUMANI("Hamza tumani","Toshkent shahri"),
    MIROBOD_TUMANI("Mirobod tumani","Toshkent shahri"),
    MIRZO_ULUGBEK_TUMANI("Mirzo Ulug'bek tumani","Toshkent shahri"),
    SERGELI_TUMANI("Sergeli tumani","Toshkent shahri"),
    SHAYXONTOHUR_TUMANI("Shayxontohur tumani","Toshkent shahri"),
    OLMAZOR_TUMANI("Olmazor tumani","Toshkent shahri"),
    UCHTEPA_TUMANI("Uchtepa tumani","Toshkent shahri"),
    YAKKASAROY_TUMANI("Yakkasaroy tumani","Toshkent shahri"),
    YUNUSOBOD_TUMANI("Yunusobod tumani","Toshkent shahri"),
    YANGIHAYOT_TUMANI("Yangihayot tumani","Toshkent shahri"),


    //SIRDARYO VILOYATIGA TEGISHLI TUMANLAR
    SIRDARYO_TUMANI("Sirdaryo tumani","Sirdaryo viloyati"),
    YANGIYER_SHAHRI("Yangiyer shahri","Sirdaryo viloyati"),
    GULISTON_SHAHRI("Guliston shahri","Sirdaryo viloyati"),
    GULISTON_TUMANI("Guliston tumani","Sirdaryo viloyati"),
    XOVOS_TUMANI("Xovos tumani","Sirdaryo viloyati"),
//    OQOLTIN_TUMANI("Oqoltin tumani","Sirdaryo viloyati"),
//    BOYOVUT_TUMANI("Boyovut tumani","Sirdaryo viloyati"),
//    MIRZAOBOD_TUMANI("Mirzaobod tumani","Sirdaryo viloyati"),
//    SAYXUNOBOD_TUMANI("Sayxunobod tumani","Sirdaryo viloyati"),
//    SARDOBA_TUMANI("Sardoba tumani","Sirdaryo viloyati"),
//    SHIRIN_SHAHRI("Shirin shahri","Sirdaryo viloyati"),


    //JIZZAX VILOYATIGA TEGISHLI TUMANLAR
    JIZZAX_SHAHRI("Jizzax shahri","Jizzax viloyati"),
    FORISH_TUMANI("Forish tumani","Jizzax viloyati"),
//    ARNASOY_TUMANI("Arnasoy tumani","Jizzax viloyati"),
//    BAXMAL_TUMANI("Baxmal tumani","Jizzax viloyati"),
//    DOSTLIK_TUMANI("Do'stlik tumani","Jizzax viloyati"),
//    GALLAOROL_TUMANI("G'allaorol tumani","Jizzax viloyati"),
//    SHAROF_RASHIDOV_TUMANI("Sharof Rashidov tumani","Jizzax viloyati"),
//    MIRZACHOL_TUMANI("Mirzacho'l tumani","Jizzax viloyati"),
//    PAXTAKOR_TUMANI("Paxtakor tumani","Jizzax viloyati"),
//    YANGIOBOD_TUMANI("Yangiobod tumani","Jizzax viloyati"),
//    ZOMIN_TUMANI("Zomin tumani","Jizzax viloyati"),
//    ZAFAROBOD_TUMANI("Zafarobod tumani","Jizzax viloyati"),
//    ZARBDOR_TUMANI("Zarbdor tumani","Jizzax viloyati"),


    //SAMARQAND VILOYATIGA TEGISHLI TUMANLAR
    BULUNGUR_TUMANI("Bulung'ur tumani","Samarqand viloyati"),
    URGUT_TUMANI("Urgut tumani","Samarqand viloyati"),
    SAMARQAND_SHAHRI("Samarqand shahri","Samarqand viloyati"),
    QOSHRABOT_TUMANI("Qo'shrabot tumani","Samarqand viloyati"),
    SAMARQAND_TUMANI("Samarqand tumani","Samarqand viloyati"),
//    ISHTIXON_TUMANI("Ishtixon tumani","Samarqand viloyati"),
//    JOMBOY_TUMANI("Jomboy tumani","Samarqand viloyati"),
//    KATTAQORGON_TUMANI("Kattaqo'rg'on tumani","Samarqand viloyati"),
//    NARPAY_TUMANI("Narpay tumani","Samarqand viloyati"),
//    NUROBOD_TUMANI("Nurobod tumani","Samarqand viloyati"),
//    OQDARYO_TUMANI("Oqdaryo tumani","Samarqand viloyati"),
//    PAXTACHI_TUMANI("Paxtachi tumani","Samarqand viloyati"),
//    PAYARIQ_TUMANI("Payariq tumani","Samarqand viloyati"),
//    PASTARGOM_TUMANI("Pastarg'om tumani","Samarqand viloyati"),
//    TOYLOQ_TUMANI("Toyloq tumani","Samarqand viloyati"),
//    KATTAQORGON_SHAHRI("Kattaqo'rg'on shahri","Samarqand viloyati"),


    //QASHQADARYO VILOYATIGA TEGISHLI TUMANLAR
    CHIROQCHI_TUMANI("Chiroqchi tumani","Qashqadaryo viloyati"),
    KOSON_TUMANI("Koson tumani","Qashqadaryo viloyati"),
    SHAHRISABZ_TUMANI("Shahrisabz tumani","Qashqadaryo viloyati"),
    QARSHI_SHAHRI("Qarshi shahri","Qashqadaryo viloyati"),
//    DEHQONOBOD_TUMANI("Dehqonobod tumani","Qashqadaryo viloyati"),
//    GUZOR_TUMANI("G'uzor tumani","Qashqadaryo viloyati"),
//    QAMASHI_TUMANI("Qamashi tumani","Qashqadaryo viloyati"),
//    QARSHI_TUMANI("Qarshi tumani","Qashqadaryo viloyati"),
//    KASBI_TUMANI("Kasbi tumani","Qashqadaryo viloyati"),
//    KITOB_TUMANI("Kitob tumani","Qashqadaryo viloyati"),
//    MIRISHKOR_TUMANI("Mirishkor tumani","Qashqadaryo viloyati"),
//    MUBORAK_TUMANI("Muborak tumani","Qashqadaryo viloyati"),
//    NISHON_TUMANI("Nishon tumani","Qashqadaryo viloyati"),
//    YAKKABOG_TUMANI("Yakkabog' tumani","Qashqadaryo viloyati"),
//    KOKDALA_TUMANI("Ko'kdala tumani","Qashqadaryo viloyati"),
//    SHAHRISABZ_SHAHRI("Shahrisabz shahri","Qashqadaryo viloyati"),


    //SURXONDARYO VILOYATIGA TEGISHLI TUMANLAR
    TERMIZ_SHAHRI("Termiz shahri","Surxondaryo viloyati"),
    UZUN_TUMANI("Uzun tumani","Surxondaryo viloyati"),
    JARQORGON_TUMANI("Jarqo'rg'on tumani","Surxondaryo viloyati"),
    SHORCHI_TUMANI("Sho'rchi tumani","Surxondaryo viloyati"),
//    ANGOR_TUMANI("Angor tumani","Surxondaryo viloyati"),
//    BOYSUN_TUMANI("Boysun tumani","Surxondaryo viloyati"),
//    DENOV_TUMANI("Denov tumani","Surxondaryo viloyati"),
//    DENOV_SHAHRI("Denov shahri","Surxondaryo viloyati"),
//    QIZIRIQ_TUMANI("Qiziriq tumani","Surxondaryo viloyati"),
//    QUMQORGON_TUMANI("Qumqo'rg'on tumani","Surxondaryo viloyati"),
//    MUZRABOT_TUMANI("Muzrabot tumani","Surxondaryo viloyati"),
//    OLTINSOY_TUMANI("Oltinsoy tumani","Surxondaryo viloyati"),
//    SARIOSIYO_TUMANI("Sariosiyo tumani","Surxondaryo viloyati"),
//    SHEROBOD_TUMANI("Sherobod tumani","Surxondaryo viloyati"),
//    TERMIZ_TUMANI("Termiz tumani","Surxondaryo viloyati"),
//    BANDIXON_TUMANI("Bandixon tumani","Surxondaryo viloyati"),


    //NAVOIY VILOYTIGA TEGISHLI TUMANLAR
    KARMANA_TUMANI("Karmana tumani","Navoiy viloyati"),
    QIZILTEPA_TUMANI("Qiziltepa tumani","Navoiy viloyati"),
    NAVOIY_SHAHRI("Navoiy shahri","Navoiy viloyati"),
//    NUROTA_TUMANI("Nurota tumani","Navoiy viloyati"),
//    NAVBAHOR_TUMANI("Navbahor tumani","Navoiy viloyati"),
//    XATIRCHI_TUMANI("Xatirchi tumani","Navoiy viloyati"),
//    KONIMEX_TUMANI("Konimex tumani","Navoiy viloyati"),
//    UCHQUDUQ_TUMANI("Uchquduq tumani","Navoiy viloyati"),
//    TOMDI_TUMANI("Tomdi tumani","Navoiy viloyati"),
//    ZARAFSHON_SHAHRI("Zarafshon shahri","Navoiy viloyati"),
//    GAZGON_SHAHRI("G'azg'on shahri","Navoiy viloyati"),


    //BUXORO VILOYATIGA TEGISHLI TUMANLAR
    BUXORO_TUMANI("Buxoro tumani", "Buxoro viloyati"),
    BUXORO_SHAHRI("Buxoro shahri", "Buxoro viloyati"),
    GIJDUVON_TUMANI("G'ijduvon tumani", "Buxoro viloyati"),
    KOGON_TUMANI("Kogon tumani", "Buxoro viloyati"),
    QORAKOL_TUMANI("Qorako'l tumani", "Buxoro viloyati"),
    PESHKU_TUMANI("Peshku tumani", "Buxoro viloyati"),
    ROMITAN_TUMANI("Romitan tumani", "Buxoro viloyati"),
//    OLOT_TUMANI("Olot tumani", "Buxoro viloyati"),
//    JONDOR_TUMANI("Jondor tumani", "Buxoro viloyati"),
//    QOROVULBOZOR_TUMANI("Qorovulbozor tumani", "Buxoro viloyati"),
//    SHOFIRKON_TUMANI("Shofirkon tumani", "Buxoro viloyati"),
//    VOBKENT_TUMANI("Vobkent tumani", "Buxoro viloyati"),


    //XORAZM VILOYATIGA TEGISHLI TUMANLAR
    BOGOT_TUMANI("Bog'ot tumani","Xorazm viloyati"),
    GURLAN_TUMANI("Gurlan tumani","Xorazm viloyati"),
    XONQA_TUMANI("Xonqa tumani","Xorazm viloyati"),
    HAZORASP_TUMANI("Hazorasp tumani","Xorazm viloyati"),
    YANGIBOZOR_TUMANI("Yangibozor tumani","Xorazm viloyati"),
    QOSHKOPIR_TUMANI("Qo'shko'pir tumani","Xorazm viloyati"),
    SHOVOT_TUMANI("Shovot tumani","Xorazm viloyati"),
    URGANCH_SHAHRI("Urganch shahri","Xorazm viloyati"),
    URGANCH_TUMANI("Urganch tumani","Xorazm viloyati"),
//    XIVA_TUMANI("Xiva tumani","Xorazm viloyati"),
//    XIVA_SHAHRI("Xiva shahri","Xorazm viloyati"),
//    YANGIARIQ_TUMANI("Yangiariq tumani","Xorazm viloyati"),
//    TUPROQQALA_TUMANI("Tuproqqal'a tumani","Xorazm viloyati"),


    //QORAQALPOGISTON AVTONOM RESPUBLIKASIGA TEGISHLI TUMANLAR
    TORTKOL_TUMANI("To'rtko'l tumani","Qoraqalpog'iston respublikasi"),
    XOJAYLI_TUMANI("Xo'jayli tumani","Qoraqalpog'iston respublikasi"),
    QONGIROT_TUMANI("Qo'ng'irot tumani","Qoraqalpog'iston respublikasi"),
    NUKUS_SHAHRI("Nukus shahri","Qoraqalpog'iston respublikasi");
//    AMUDARYO_TUMANI("Amudaryo tumani","Qoraqalpog'iston respublikasi"),
//    BERUNIY_TUMANI("Beruniy tumani","Qoraqalpog'iston respublikasi"),
//    CHIMBOY_TUMANI("Chimboy tumani","Qoraqalpog'iston respublikasi"),
//    ELLIKQALA_TUMANI("Ellikqal'a tumani","Qoraqalpog'iston respublikasi"),
//    KEYGELI_TUMANI("Ketgeli tumani","Qoraqalpog'iston respublikasi"),
//    MOYNOQ_TUMANI("Mo'ynoq tumani","Qoraqalpog'iston respublikasi"),
//    NUKUS_TUMANI("Nukus tumani","Qoraqalpog'iston respublikasi"),
//    QANLIKOL_TUMANI("Qalniko'l tumani","Qoraqalpog'iston respublikasi"),
//    QORAOZAK_TUMANI("Qorao'zak tumani","Qoraqalpog'iston respublikasi"),
//    SHUMANAY_TUMANI("Shumanay tumani","Qoraqalpog'iston respublikasi"),
//    TAXTAKOPIR_TUMANI("Taxtako'pir tumani","Qoraqalpog'iston respublikasi");


    private String originalName;
    private String regionName;

    DistrictName(String originalName, String regionName) {
        this.originalName = originalName;
        this.regionName = regionName;
    }

    public String getOriginalName() {
        return originalName;
    }

    public String getRegionName(){
        return regionName;
    }
}

