package uz.pdp.qimmataptekatest.entity.enums;

public enum TgLanguage {
    UZ,
    RU
}
