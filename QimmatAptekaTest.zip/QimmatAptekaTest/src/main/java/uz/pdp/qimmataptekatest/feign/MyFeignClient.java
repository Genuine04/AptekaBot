package uz.pdp.qimmataptekatest.feign;

import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(value = "product", url = "http://PRODUCT")
public interface MyFeignClient {

//    @GetMapping
//    List<ProductResponseModel> getAllProductsByName(@RequestParam String productName);

}
