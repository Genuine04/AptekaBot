package uz.pdp.qimmataptekatest.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import uz.pdp.qimmataptekatest.payload.TgConstants;
import uz.pdp.qimmataptekatest.payload.TgResult;

@FeignClient(url = TgConstants.TELEGRAM_BASE_URL_WITHOUT_BOT,
        name = "BoltaFeign")
public interface TgFeign {

    @PostMapping("{path}/sendMessage")
    TgResult sendMessageToUser(@PathVariable(value = "path") String path, @RequestBody SendMessage sendMessage);

}
