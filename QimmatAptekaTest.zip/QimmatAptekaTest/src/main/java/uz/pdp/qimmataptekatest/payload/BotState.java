package uz.pdp.qimmataptekatest.payload;

public enum BotState {

    START,
    VILOYATLAR,
    TUMANLAR,
    ORTGA,
    DORILARNI_IZLASH,
    AXBOROT,
    IZOH_QOLDIRISH,
    QANDAY_QILIB_QOLLASH,
    DORI_IZLASH_MAIN,
    SEARCH,
    IZOH_JONATISH;

}
