package uz.pdp.qimmataptekatest.payload;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import uz.pdp.qimmataptekatest.entity.enums.TgLanguage;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DefaultUser {

    private BotState botState;

    private TgLanguage language = TgLanguage.UZ;
}
