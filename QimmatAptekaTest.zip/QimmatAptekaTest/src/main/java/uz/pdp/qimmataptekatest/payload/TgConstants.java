package uz.pdp.qimmataptekatest.payload;

public interface TgConstants {
    String TELEGRAM_BASE_URL = "https://api.telegram.org/bot";
    String TELEGRAM_BASE_URL_WITHOUT_BOT = "https://api.telegram.org/";
    String BOT_TOKEN = "5049026983:AAHjxVS4KdTmMLp4x_ir9khH4w1tB4h6pPQ";
    String PATH_FEIGN = "bot5049026983:AAHjxVS4KdTmMLp4x_ir9khH4w1tB4h6pPQ";
}
