package uz.pdp.qimmataptekatest.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import uz.pdp.qimmataptekatest.entity.District;
import uz.pdp.qimmataptekatest.entity.Region;

import java.util.List;

public interface DistrictRepo extends JpaRepository<District, Long> {

    List<District> findAllByRegion(Region region);
}
