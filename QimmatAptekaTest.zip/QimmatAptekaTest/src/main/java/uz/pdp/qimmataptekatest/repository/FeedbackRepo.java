package uz.pdp.qimmataptekatest.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import uz.pdp.qimmataptekatest.entity.Feedback;

public interface FeedbackRepo extends JpaRepository<Feedback, Long> {
}
