package uz.pdp.qimmataptekatest.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import uz.pdp.qimmataptekatest.entity.Region;

import java.util.Optional;

public interface RegionRepo extends JpaRepository<Region, Long> {

    Optional<Region> findByRegionName(String regionName);
}
