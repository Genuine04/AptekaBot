package uz.pdp.qimmataptekatest.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import uz.pdp.qimmataptekatest.entity.TgUser;

import java.util.Optional;

public interface UserRepo extends JpaRepository<TgUser, Long> {

    boolean existsByChatId(String chatId);

    Optional<TgUser> findByChatId(String chatId);
}
