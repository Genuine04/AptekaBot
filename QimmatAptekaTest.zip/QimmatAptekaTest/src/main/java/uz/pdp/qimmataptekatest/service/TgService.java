package uz.pdp.qimmataptekatest.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.telegram.telegrambots.meta.api.objects.Update;
import uz.pdp.qimmataptekatest.entity.TgUser;
import uz.pdp.qimmataptekatest.payload.BotState;
import uz.pdp.qimmataptekatest.payload.DefaultUser;
import uz.pdp.qimmataptekatest.repository.UserRepo;

import java.util.Optional;

@Service
@RequiredArgsConstructor
public class TgService {

    private final WebhookService webhookService;

    private final UserRepo userRepo;

    private final DefaultUser defaultUser;


    public void getUpdate(Update update) {
        if (update.hasMessage()) {
            if (update.getMessage().hasText()) {
                String text = update.getMessage().getText();
                System.out.println(text);

                if ("/start".equals(text)) {
                    webhookService.whenStart(update);
                    TgUser user = new TgUser();
                    user.setChatId(update.getMessage().getChatId().toString());
                    user.setUsername(update.getMessage().getFrom().getUserName());
                    user.setFirstName(update.getMessage().getFrom().getFirstName());
                    user.setLastName(update.getMessage().getFrom().getLastName());
                    if (!userRepo.existsByChatId(update.getMessage().getChatId().toString())){
                        TgUser save = userRepo.save(user);
                    }
                } else if ("\uD83C\uDDF7\uD83C\uDDFAРус/\uD83C\uDDFA\uD83C\uDDFFUzb".equals(text)) {
                    webhookService.whenTilniTanlash(update);
                } else if ("\uD83C\uDDFA\uD83C\uDDFFO'zbekcha\uD83C\uDDFA\uD83C\uDDFF".equals(text)) {
                    webhookService.whenUz(update);
                } else if ("\uD83C\uDDF7\uD83C\uDDFAРусский\uD83C\uDDF7\uD83C\uDDFA".equals(text)) {
                    webhookService.whenRu(update);
                } else if ("\uD83D\uDD0DDorilarni izlash\uD83D\uDD0D".equals(text) ||
                        "\uD83D\uDD0DПоиск лекарств\uD83D\uDD0D".equals(text)) {
                    webhookService.whenDorilarniIzlash(update);
                } else if ("❗️Biz haqimizda❗️".equals(text) ||
                        "❗️О нас❗️".equals(text)){
                    webhookService.whenBizHaqimizda(update);
                } else if ("\uD83D\uDCDEAloqa\uD83D\uDCDE".equals(text) ||
                        "\uD83D\uDCDEКонтакты\uD83D\uDCDE".equals(text)){
                    webhookService.whenAloqa(update);
                } else if ("\uD83D\uDCD6Axborot\uD83D\uDCD6".equals(text) ||
                        "\uD83D\uDCD6Информация\uD83D\uDCD6".equals(text)) {
                    webhookService.whenAxborot(update);
                } else if ("\uD83D\uDCDDIzoh qoldirish\uD83D\uDCDD".equals(text) ||
                        "\uD83D\uDCDDОставить отзыв\uD83D\uDCDD".equals(text)) {
                    webhookService.whenIzohQoldirish(update);
                } else if ("⬆️Bosh sahifa⬆️".equals(text) ||
                        "⬆️Главная⬆️".equals(text)) {
                    webhookService.whenStart(update);
                } else if ("❌Bekor qilish❌".equals(text) ||
                        "❌Отмена❌".equals(text)) {
                    webhookService.whenStart(update);
                } else if ("⬅️Ortga⬅️".equals(text) ||
                        "⬅️Назад⬅️".equals(text)) {
                    System.out.println(defaultUser.getBotState());
                    if (defaultUser.getBotState().equals(BotState.SEARCH)) {
                        webhookService.whenViloyatTumanlari(update);
                    } else if (defaultUser.getBotState().equals(BotState.DORI_IZLASH_MAIN)) {
                        webhookService.whenDorilarniIzlash(update);
                    } else {
                        webhookService.whenStart(update);
                    }
                }

                else if (defaultUser.getBotState().equals(BotState.VILOYATLAR)) {
                    webhookService.whenViloyatTumanlari(update);
                } else if (defaultUser.getBotState().equals(BotState.DORI_IZLASH_MAIN)){
                    webhookService.whenDoriIzlashMain(update);
                } else if (defaultUser.getBotState().equals(BotState.IZOH_JONATISH)){
                    webhookService.whenIzohJonatish(update);
                }


                else if (defaultUser.getBotState().equals(BotState.SEARCH)){
                    //TODO GET PRODUCTS FROM PRODUCT SERVICE
                }

                } else if (update.getMessage().hasContact()) {
                    webhookService.whenRaqamJonatildi(update);
                    String phoneNumber = update.getMessage().getContact().getPhoneNumber();
                    System.out.println(phoneNumber);
                    String chatId = update.getMessage().getChatId().toString();
                    Optional<TgUser> optionalTgUser = userRepo.findByChatId(chatId);
                    if (optionalTgUser.isPresent()) {
                        TgUser tgUser = optionalTgUser.get();
                        tgUser.setPhoneNumber(phoneNumber);
                        userRepo.save(tgUser);
                    }
                }
            } else if (update.hasCallbackQuery()) {

            }
    }
}
