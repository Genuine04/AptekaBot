package uz.pdp.qimmataptekatest.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.api.objects.Update;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.ReplyKeyboardMarkup;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.buttons.KeyboardButton;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.buttons.KeyboardRow;
import uz.pdp.qimmataptekatest.entity.District;
import uz.pdp.qimmataptekatest.entity.Feedback;
import uz.pdp.qimmataptekatest.entity.Region;
import uz.pdp.qimmataptekatest.entity.TgUser;
import uz.pdp.qimmataptekatest.entity.enums.TgLanguage;
import uz.pdp.qimmataptekatest.feign.TgFeign;
import uz.pdp.qimmataptekatest.payload.BotState;
import uz.pdp.qimmataptekatest.payload.DefaultUser;
import uz.pdp.qimmataptekatest.payload.TgConstants;
import uz.pdp.qimmataptekatest.payload.TgResult;
import uz.pdp.qimmataptekatest.repository.DistrictRepo;
import uz.pdp.qimmataptekatest.repository.FeedbackRepo;
import uz.pdp.qimmataptekatest.repository.RegionRepo;
import uz.pdp.qimmataptekatest.repository.UserRepo;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class WebhookService {

    private final RestTemplate restTemplate;

    private final RegionRepo regionRepo;

    private final DistrictRepo districtRepo;

    private final DefaultUser defaultUser;

    private final FeedbackRepo feedbackRepo;

    private final UserRepo userRepo;

    private final TgFeign tgFeign;


    //START
    public ReplyKeyboardMarkup forStart() {
        ReplyKeyboardMarkup markup = new ReplyKeyboardMarkup();
        List<KeyboardRow> rowList = new ArrayList<>();
        KeyboardRow row1 = new KeyboardRow();
        KeyboardRow row2 = new KeyboardRow();
        KeyboardButton row1button1 = new KeyboardButton();
        KeyboardButton row1button2 = new KeyboardButton();
        KeyboardButton row2button1 = new KeyboardButton();
        KeyboardButton row2button2 = new KeyboardButton();
        if (defaultUser.getLanguage().equals(TgLanguage.RU)) {
            row1button1.setText("\uD83D\uDD0DПоиск лекарств\uD83D\uDD0D");
            row1.add(row1button1);
            row1button2.setText("\uD83D\uDCDDОставить отзыв\uD83D\uDCDD");
            row1.add(row1button2);
            rowList.add(row1);
            row2button1.setText("\uD83D\uDCD6Информация\uD83D\uDCD6");
            row2.add(row2button1);
            row2button2.setText("\uD83C\uDDF7\uD83C\uDDFAРус/\uD83C\uDDFA\uD83C\uDDFFUzb");
            row2.add(row2button2);
            rowList.add(row2);
        }else {
            row1button1.setText("\uD83D\uDD0DDorilarni izlash\uD83D\uDD0D");
            row1.add(row1button1);
            row1button2.setText("\uD83D\uDCDDIzoh qoldirish\uD83D\uDCDD");
            row1.add(row1button2);
            rowList.add(row1);
            row2button1.setText("\uD83D\uDCD6Axborot\uD83D\uDCD6");
            row2.add(row2button1);
            row2button2.setText("\uD83C\uDDF7\uD83C\uDDFAРус/\uD83C\uDDFA\uD83C\uDDFFUzb");
            row2.add(row2button2);
            rowList.add(row2);
        }
        markup.setKeyboard(rowList);
        markup.setSelective(true);
        markup.setResizeKeyboard(true);
        return markup;
    }



    //START
    public void whenStart(Update update) {
        if (defaultUser.getLanguage().equals(TgLanguage.RU)) {
            SendMessage sendMessage = new SendMessage(update.getMessage().getChatId().toString(),
                    "Выберите интересующий Вас раздел:");
            sendMessage.setReplyMarkup(forStart());

            TgResult tgResult = tgFeign.sendMessageToUser(TgConstants.PATH_FEIGN, sendMessage);
        } else {
            SendMessage sendMessage = new SendMessage(update.getMessage().getChatId().toString(),
                    "Kerakli bo'limni tanlang:");
            sendMessage.setReplyMarkup(forStart());

            TgResult tgResult = tgFeign.sendMessageToUser(TgConstants.PATH_FEIGN, sendMessage);
        }
    }



    //TILNI TANLASH
    public ReplyKeyboardMarkup forTilniTanlash(){
        ReplyKeyboardMarkup markup = new ReplyKeyboardMarkup();
        List<KeyboardRow> rowList = new ArrayList<>();
        KeyboardRow row1 = new KeyboardRow();
        KeyboardRow row2 = new KeyboardRow();
        row1.add("\uD83C\uDDFA\uD83C\uDDFFO'zbekcha\uD83C\uDDFA\uD83C\uDDFF");
        row1.add("\uD83C\uDDF7\uD83C\uDDFAРусский\uD83C\uDDF7\uD83C\uDDFA");
        rowList.add(row1);
        rowList.add(row2);

        markup.setKeyboard(rowList);
        markup.setSelective(true);
        markup.setResizeKeyboard(true);
        return markup;
    }



    //TILNI TANLASH
    public void whenTilniTanlash(Update update) {
        SendMessage sendMessage = new SendMessage(update.getMessage().getChatId().toString(),
                "\uD83C\uDDF7\uD83C\uDDFAВыберите язык:\n" +
                        "\uD83C\uDDFA\uD83C\uDDFFTilni tanlash:");
        sendMessage.setReplyMarkup(forTilniTanlash());

        TgResult tgResult = tgFeign.sendMessageToUser(TgConstants.PATH_FEIGN, sendMessage);
    }



    //DORILARNI IZLASH
    public ReplyKeyboardMarkup forDorilarniIzlash() {
        defaultUser.setBotState(BotState.VILOYATLAR);
        ReplyKeyboardMarkup markup = new ReplyKeyboardMarkup();
        List<KeyboardRow> rowList = new ArrayList<>();
        KeyboardRow row = new KeyboardRow();
        List<Region> regions = regionRepo.findAll();
        for (int i = 0; i < regions.size(); i++) {
            row.add(regions.get(i).getRegionName());
            if (i%2==1){
                        rowList.add(row);
                        row = new KeyboardRow();
            }
        }
        row = new KeyboardRow();
        if (defaultUser.getLanguage().equals(TgLanguage.RU)) {
            row.add("⬅️Назад⬅️");
        } else {
            row.add("⬅️Ortga⬅️");
        }
        rowList.add(row);
        markup.setKeyboard(rowList);
        markup.setSelective(true);
        markup.setResizeKeyboard(true);
        return markup;
    }



    //DORILARNI IZLASH
    public void whenDorilarniIzlash(Update update) {
        if (defaultUser.getLanguage().equals(TgLanguage.RU)) {
            SendMessage sendMessage = new SendMessage(update.getMessage().getChatId().toString(),
                    "Выберите город Ташкент, область:");
            sendMessage.setReplyMarkup(forDorilarniIzlash());

            TgResult tgResult = tgFeign.sendMessageToUser(TgConstants.PATH_FEIGN, sendMessage);
        } else {
            SendMessage sendMessage = new SendMessage(update.getMessage().getChatId().toString(),
                    "Toshkent shahri, viloyatni tanlang:");
            sendMessage.setReplyMarkup(forDorilarniIzlash());

            TgResult tgResult = tgFeign.sendMessageToUser(TgConstants.PATH_FEIGN, sendMessage);
        }
    }



    //IZOH QOLDIRISH
    public ReplyKeyboardMarkup forIzohQoldirish(){
        ReplyKeyboardMarkup markup = new ReplyKeyboardMarkup();
        List<KeyboardRow> rowList = new ArrayList<>();
        KeyboardRow row1 = new KeyboardRow();
        KeyboardRow row2 = new KeyboardRow();
        KeyboardButton row1Button1 = new KeyboardButton();
        if (defaultUser.getLanguage().equals(TgLanguage.RU)) {
            row1Button1.setText("\uD83D\uDCF1Отправить контакт\uD83D\uDCF1");
            row1Button1.setRequestContact(true);
            row1.add(row1Button1);
            row2.add("❌Отмена❌");
            rowList.add(row1);
            rowList.add(row2);
        } else {
            row1Button1.setText("\uD83D\uDCF1Telefon raqamni jo'natish\uD83D\uDCF1");
            row1Button1.setRequestContact(true);
            row1.add(row1Button1);
            row2.add("❌Bekor qilish❌");
            rowList.add(row1);
            rowList.add(row2);
        }

        markup.setKeyboard(rowList);
        markup.setSelective(true);
        markup.setResizeKeyboard(true);
        return markup;
    }



    //IZOH QOLDIRISH
    public void whenIzohQoldirish(Update update) {
        if (defaultUser.getLanguage().equals(TgLanguage.RU)) {
            SendMessage sendMessage = new SendMessage(update.getMessage().getChatId().toString(),
                    "Перед тем, как оставить отзыв, отправьте свой контакт:");
            sendMessage.setReplyMarkup(forIzohQoldirish());

            TgResult tgResult = tgFeign.sendMessageToUser(TgConstants.PATH_FEIGN, sendMessage);
        } else {
            SendMessage sendMessage = new SendMessage(update.getMessage().getChatId().toString(),
                    "Izoh qoldirishdan avval telefon raqamingizni jo’nating:");
            sendMessage.setReplyMarkup(forIzohQoldirish());

            TgResult tgResult = tgFeign.sendMessageToUser(TgConstants.PATH_FEIGN, sendMessage);
        }
    }



    //RAQAM JONATILDI
    public ReplyKeyboardMarkup forRaqamJonatildi(){
        defaultUser.setBotState(BotState.IZOH_JONATISH);
        ReplyKeyboardMarkup markup = new ReplyKeyboardMarkup();
        List<KeyboardRow> rowList = new ArrayList<>();
        KeyboardRow row1 = new KeyboardRow();
        if (defaultUser.getLanguage().equals(TgLanguage.RU)) {
            row1.add("❌Отмена❌");
        } else {
            row1.add("❌Bekor qilish❌");
        }
        rowList.add(row1);

        markup.setKeyboard(rowList);
        markup.setSelective(true);
        markup.setResizeKeyboard(true);
        return markup;
    }



    //RAQAM JONATILDI
    public void whenRaqamJonatildi(Update update) {
        if (defaultUser.getLanguage().equals(TgLanguage.RU)) {
            SendMessage sendMessage = new SendMessage(update.getMessage().getChatId().toString(),
                    "Пожалуйста, напишите и отправьте нам свой отзыв/пожелание/жалобу:\n" +
                            "\n" +
                            "(1-256 символов)");
            sendMessage.setReplyMarkup(forRaqamJonatildi());

            TgResult tgResult = tgFeign.sendMessageToUser(TgConstants.PATH_FEIGN, sendMessage);
        } else {
            SendMessage sendMessage = new SendMessage(update.getMessage().getChatId().toString(),
                    "Iltimos, bizga izoh/istak/shikoyat yozib jo’nating:\n" +
                            "\n" +
                            "(1-256 belgi)");
            sendMessage.setReplyMarkup(forRaqamJonatildi());

            TgResult tgResult = tgFeign.sendMessageToUser(TgConstants.PATH_FEIGN, sendMessage);
        }
    }



    //O'ZBEKCHA TIL TANLANSA
    public void whenUz(Update update) {
        defaultUser.setLanguage(TgLanguage.UZ);
        whenStart(update);
    }



    //RUSCHA TIL TANLANSA
    public void whenRu(Update update){
        defaultUser.setLanguage(TgLanguage.RU);
        whenStart(update);
    }



    //VILOYAT TUMANLARI
    public ReplyKeyboardMarkup forViloyatTumanlari(Update update){
        defaultUser.setBotState(BotState.TUMANLAR);
        ReplyKeyboardMarkup markup = new ReplyKeyboardMarkup();
        List<KeyboardRow> rowList = new ArrayList<>();
        KeyboardRow row = new KeyboardRow();
        KeyboardButton rowbutton1 = new KeyboardButton();
        KeyboardButton rowbutton2 = new KeyboardButton();
        String text = update.getMessage().getText();

        for (long i = 1; i <= 14; i++) {
            Optional<Region> optionalRegion = regionRepo.findByRegionName(text);
            if (optionalRegion.isPresent()){
                Region region = optionalRegion.get();
                List<District> districts = districtRepo.findAllByRegion(region);
                System.out.println(districts);
                for (int i1 = 0; i1 < districts.size(); i1++) {
                    row.add(districts.get(i1).getDistrictName());
                    if (i1%2==1){
                        rowList.add(row);
                        row = new KeyboardRow();
                    }
                }
                break;
            }
        }
        rowList.add(row);
        row = new KeyboardRow();
        if (defaultUser.getLanguage().equals(TgLanguage.RU)) {
            rowbutton1.setText("⬅️Назад⬅️");
            row.add(rowbutton1);
            rowbutton2.setText("⬆️Главная⬆️");
            row.add(rowbutton2);
            rowList.add(row);
        } else {
            rowbutton1.setText("⬅️Ortga⬅️");
            row.add(rowbutton1);
            rowbutton2.setText("⬆️Bosh sahifa⬆️");
            row.add(rowbutton2);
            rowList.add(row);
        }
        markup.setKeyboard(rowList);
        markup.setSelective(true);
        markup.setResizeKeyboard(true);
        return markup;
    }



    //VILOYAT TUMANLARI
    public void whenViloyatTumanlari(Update update) {
        if (defaultUser.getLanguage().equals(TgLanguage.RU)){
            SendMessage sendMessage = new SendMessage(update.getMessage().getChatId().toString(),
                    "Выберите город/округ:");
            sendMessage.setReplyMarkup(forViloyatTumanlari(update));

            TgResult tgResult = tgFeign.sendMessageToUser(TgConstants.PATH_FEIGN, sendMessage);
        } else {
            SendMessage sendMessage = new SendMessage(update.getMessage().getChatId().toString(),
                    "Shahar/Tumanni tanlang:");
            sendMessage.setReplyMarkup(forViloyatTumanlari(update));

            TgResult tgResult = tgFeign.sendMessageToUser(TgConstants.PATH_FEIGN, sendMessage);
        }
        defaultUser.setBotState(BotState.DORI_IZLASH_MAIN);
    }



    //AXBOROT
    public ReplyKeyboardMarkup forAxborot(){
        defaultUser.setBotState(BotState.AXBOROT);
        ReplyKeyboardMarkup markup = new ReplyKeyboardMarkup();
        List<KeyboardRow> rowList = new ArrayList<>();
        KeyboardRow row1 = new KeyboardRow();
        KeyboardRow row2 = new KeyboardRow();
        KeyboardButton row1button1 = new KeyboardButton();
        KeyboardButton row1button2 = new KeyboardButton();
        if (defaultUser.getLanguage().equals(TgLanguage.RU)) {
            row1button1.setText("❗️О нас❗️");
            row1.add(row1button1);
            row1button2.setText("\uD83D\uDCDEКонтакты\uD83D\uDCDE");
            row1.add(row1button2);
            rowList.add(row1);
            row2.add("⬅️Назад⬅️");
            rowList.add(row2);
        } else {
            row1button1.setText("❗️Biz haqimizda❗️");
            row1.add(row1button1);
            row1button2.setText("\uD83D\uDCDEAloqa\uD83D\uDCDE");
            row1.add(row1button2);
            rowList.add(row1);
            row2.add("⬅️Ortga⬅️");
            rowList.add(row2);
        }

        markup.setKeyboard(rowList);
        markup.setSelective(true);
        markup.setResizeKeyboard(true);
        return markup;
    }



    //AXBOROT
    public void whenAxborot(Update update) {
        if (defaultUser.getLanguage().equals(TgLanguage.RU)) {
            SendMessage sendMessage = new SendMessage(update.getMessage().getChatId().toString(),
                    "Выберите интересующий Вас раздел:");
            sendMessage.setReplyMarkup(forAxborot());

            TgResult tgResult = tgFeign.sendMessageToUser(TgConstants.PATH_FEIGN, sendMessage);
        } else {
            SendMessage sendMessage = new SendMessage(update.getMessage().getChatId().toString(),
                    "Kerakli bo'limni tanlang:");
            sendMessage.setReplyMarkup(forAxborot());

            TgResult tgResult = tgFeign.sendMessageToUser(TgConstants.PATH_FEIGN, sendMessage);
        }
    }



    //DORI IZLASH MAIN
    public ReplyKeyboardMarkup forDoriIzlashMain(){
        defaultUser.setBotState(BotState.SEARCH);
        ReplyKeyboardMarkup markup = new ReplyKeyboardMarkup();
        List<KeyboardRow> rowList = new ArrayList<>();
        KeyboardRow row = new KeyboardRow();
        KeyboardButton rowbutton1 = new KeyboardButton();
        KeyboardButton rowbutton2 = new KeyboardButton();
        if (defaultUser.getLanguage().equals(TgLanguage.RU)){
            rowbutton1.setText("⬅️Назад⬅️");
            row.add(rowbutton1);
            rowbutton2.setText("⬆️Главная⬆️");
            row.add(rowbutton2);
            rowList.add(row);
        } else {
            rowbutton1.setText("⬅️Ortga⬅️");
            row.add(rowbutton1);
            rowbutton2.setText("⬆️Bosh sahifa⬆️");
            row.add(rowbutton2);
            rowList.add(row);
        }

        markup.setKeyboard(rowList);
        markup.setSelective(true);
        markup.setResizeKeyboard(true);
        return markup;
    }



    //DORI IZLASH MAIN
    public void whenDoriIzlashMain(Update update) {
        if (defaultUser.getLanguage().equals(TgLanguage.RU)) {
            SendMessage sendMessage = new SendMessage(update.getMessage().getChatId().toString(),
                    "Введите название лекарства, а наш бот подскажет Вам возможные варианты:\n" +
                            "\n" +
                            "Пример: анальгин\n" +
                            "(Минимум 3 символа)");
            sendMessage.setReplyMarkup(forDoriIzlashMain());

            TgResult tgResult = tgFeign.sendMessageToUser(TgConstants.PATH_FEIGN, sendMessage);
        } else {
            SendMessage sendMessage = new SendMessage(update.getMessage().getChatId().toString(),
                    "Dori nomini kiriting va bizning bot sizga mos variantlarni tanlab beradi:\n" +
                            "\n" +
                            "Misol: analgin\n" +
                            "(Kamida 3ta belgi)");
            sendMessage.setReplyMarkup(forDoriIzlashMain());

            TgResult tgResult = tgFeign.sendMessageToUser(TgConstants.PATH_FEIGN, sendMessage);
        }
    }



    //BIZ HAQIMIZDA
    public void whenBizHaqimizda(Update update) {
        if (defaultUser.getLanguage().equals(TgLanguage.RU)){
            SendMessage sendMessage = new SendMessage(update.getMessage().getChatId().toString(),
                    "Информации о нас пока нет.");
            sendMessage.setReplyMarkup(forAxborot());

            TgResult tgResult = tgFeign.sendMessageToUser(TgConstants.PATH_FEIGN, sendMessage);
        } else {
            SendMessage sendMessage = new SendMessage(update.getMessage().getChatId().toString(),
                    "Hozircha biz haqimizda ma'lumot yo'q.");
            sendMessage.setReplyMarkup(forAxborot());

            TgResult tgResult = tgFeign.sendMessageToUser(TgConstants.PATH_FEIGN, sendMessage);
        }
    }



    //ALOQA
    public void whenAloqa(Update update) {
        if (defaultUser.getLanguage().equals(TgLanguage.RU)) {
            SendMessage sendMessage = new SendMessage(update.getMessage().getChatId().toString(),
                    "Контакт:\n" +
                            "\n"+
                            "Телеграм: @Genuine04\n" +
                            "\n" +
                            "Телефон: +998996280240");
            sendMessage.setReplyMarkup(forAxborot());

            TgResult tgResult = tgFeign.sendMessageToUser(TgConstants.PATH_FEIGN, sendMessage);
        } else {
            SendMessage sendMessage = new SendMessage(update.getMessage().getChatId().toString(),
                    "Aloqa:\n" +
                            "\n" +
                            "Telegram: @Genuine04\n" +
                            "\n" +
                            "Telefon: +998996280240");
            sendMessage.setReplyMarkup(forAxborot());

            TgResult tgResult = tgFeign.sendMessageToUser(TgConstants.PATH_FEIGN, sendMessage);
        }
    }



    //IZOH JONATISH
    public void whenIzohJonatish(Update update) {
        String text = update.getMessage().getText();
        String chatId = update.getMessage().getChatId().toString();
        Optional<TgUser> optionalTgUser = userRepo.findByChatId(chatId);
        TgUser tgUser = new TgUser();
        if (optionalTgUser.isPresent()) {
            tgUser = optionalTgUser.get();
        }
        Feedback feedback = new Feedback();
        feedback.setFeedbackText(text);
        feedback.setPhoneNumber(tgUser.getPhoneNumber());
        feedbackRepo.save(feedback);
        if (defaultUser.getLanguage().equals(TgLanguage.RU)) {
            SendMessage sendMessage = new SendMessage(update.getMessage().getChatId().toString(),
                    "Спасибо, ваш комментарий принят!");
            sendMessage.setReplyMarkup(forStart());

            TgResult tgResult = tgFeign.sendMessageToUser(TgConstants.PATH_FEIGN, sendMessage);
        } else {
            SendMessage sendMessage = new SendMessage(update.getMessage().getChatId().toString(),
                    "Raxmat, izohingiz qabul qilindi!");
            sendMessage.setReplyMarkup(forStart());

            TgResult tgResult = tgFeign.sendMessageToUser(TgConstants.PATH_FEIGN, sendMessage);
        }
    }
}
